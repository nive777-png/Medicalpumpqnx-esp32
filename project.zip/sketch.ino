#include <Arduino.h>

volatile int heartbeat = 0;
bool system_active = true;

// Task 1: The Pump 
void pumpTask(void *pvParameters) {
  int count = 0;
  for (;;) {
    if (system_active) {
      count++;
      Serial.print("[PUMP] Delivering Dose: ");
      Serial.println(count);
      heartbeat++; // Kicking the watchdog
      
      // Simulate a freeze after 10 cycles
      if (count == 10) {
        Serial.println("[DEBUG] Simulating Freeze...");
        while(1) { delay(100); } 
      }
    }
    vTaskDelay(500 / portTICK_PERIOD_MS); // 500ms Interval
  }
}

// Task 2: The Watchdog
void watchdogTask(void *pvParameters) {
  int last_heartbeat = 0;
  for (;;) {
    vTaskDelay(1500 / portTICK_PERIOD_MS); // Check every 1.5s
    
    if (heartbeat == last_heartbeat) {
      Serial.println("\n[!!! ALERT !!!] WATCHDOG TRIGGERED!");
      Serial.println("[SAFE STATE] System Halted.");
      system_active = false;
      vTaskDelete(NULL); // Stop Watchdog
    }
    last_heartbeat = heartbeat;
    Serial.println("[WATCHDOG] Heartbeat OK.");
  }
}

void setup() {
  Serial.begin(115200);
  xTaskCreate(pumpTask, "Pump", 2048, NULL, 1, NULL);
  xTaskCreate(watchdogTask, "Watchdog", 2048, NULL, 2, NULL);
}

void loop() {}